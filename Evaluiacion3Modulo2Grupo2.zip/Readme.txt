
================================================================================
RPGestionator ==================================================================
================================================================================
Base de dato para la administracion de los principales procesos de
negocio, planificación de actividades y control de ejecución que se llevan a
cabo día a día en empresas de asesorías en prevención de riesgo. 

En respuesta para empresas que no poseen un sistema que les permita 
administrar toda la cantidad de información que se genera, ni controlar las 
actividades y el recurso humano. 

Este programa permite una mejor gestión, control, seguridad, y disponibilidad 
de información para la empresa y sus clientes, almacenandola y ordenaldola según
el tipo de perfil al que corresponda: Clientes, profesionales y administrativos.
Posee un sistema de Usuarios para identificar quien ingresa los datos, 
registrando y coordinando información según tipo de perfil. De esta forma se 
pueden ingresar e identificar: (a) para cada cliente pagos, visitas con chequeos,
accidentes y capacitaciones con asistentes y (b) según cliente y profesionales,
asesorías con mejoras propuestas.

================================================================================
Versión ========================================================================
================================================================================

CrossVisions ===================================================================

Versión 1.0 alfa versiones anteriores a la distribución

Versión 1.0 20-02-2021 Primera versión y final


================================================================================
Licencia =======================================================================
================================================================================

Autores
------------------------

Grupo 2; Daniel Estrada, Evange León, Hugo López, Hugo Uribe 
Awakelab,
Talento Digital 


Copias y distribución:
----------------------

- Usted puede hacer las copia que quiera de este software.

- No se permite la venta excepto si el pago corresponde al coste
del soporte  (discos, cintas, CD-ROM, etc).

ATENCION:
    Este software no tiene ninguna garantia y los autores no se hacen
    responsables de los posibles perjuicios causados por su uso.
    Usted asume los riesgos del uso de este software.

WARNING:
    This software comes with ABSOLUTELY NO WARRANTEE.
    USE AT YOUR OWN RISK!